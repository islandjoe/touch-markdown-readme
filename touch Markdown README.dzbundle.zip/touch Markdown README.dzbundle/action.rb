# Dropzone Action Info
# Name: touch Markdown README
# Description: Create/touch a README.md inside a dragged folder
# Handles: Files
# Creator: Arthur Kho
# URL: http://compendium.xyz
# Events: Dragged
# SkipConfig: No
# RunsSandboxed: No
# UniqueID: 3ade548131b4bc6c41fd0f0f8c1ce2cc
# Version: 1.0
# MinDropzoneVersion: 3.0

def dragged
  # This is a Ruby method that gets called when a user drags items onto your action.
  # You can access the received items using the $items global variable e.g.
  
  File.new($items[0] + "/README.md", "w+")
  
  # The below line tells Dropzone to end with a notification center notification
  $dz.finish("README.md created")
  
  # You should always call $dz.url or $dz.text last in your script. The below $dz.text line places text on the clipboard.
  # If you don't want to place anything on the clipboard you should still call $dz.url(false)
  $dz.url(false)
end
